document.addEventListener("DOMContentLoaded", () => {
  const searchBar = document.getElementById("searchBar");
  const filterSelect = document.getElementById("filterSelect");
  const productList = document.getElementById("productList");
  const cartCount = document.getElementById("cartCount");
  const cartContainer = document.getElementById("cartContainer");
  let cartDropdown = document.getElementById("cartDropdown");

  let products = [];
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  updateCartCount();

  // Ensure dropdown exists
  if (!cartDropdown) {
    const container = cartContainer || document.body;
    const dropdown = document.createElement("div");
    dropdown.id = "cartDropdown";
    dropdown.className = "cart-dropdown hidden";
    container.appendChild(dropdown);
    cartDropdown = dropdown;
  }

  // Fetch products (mock data)
  fetchProducts();

  function fetchProducts() {
    const mockData = [
      { name: "Teacher's Uniform", price: "₱1,600", quantity: 15, image: "../assets/images/Teacher's Uniform.jpg", sizes: "S, M, L, XL", colors: "Navy Blue, White", category: "uniforms" },
      { name: "Student Uniform", price: "₱1,150", quantity: 20, image: "../assets/images/Student Uniform.jpg", sizes: "XS, S, M, L", colors: "Blue, Gray", category: "uniforms" },
      { name: "Debutant Gown", price: "₱12,500", quantity: 5, image: "../assets/images/Debutant Gown.jpg", sizes: "Custom Fit", colors: "Pink, Ivory, Gold", category: "gowns" },
      { name: "Wedding Gown", price: "₱17,500", quantity: 3, image: "../assets/images/Wedding Gown.jpg", sizes: "Custom Fit", colors: "White, Off-White", category: "gowns" },
      { name: "Barong", price: "₱5,500", quantity: 7, image: "../assets/images/Barong.jpg", sizes: "S, M, L, XL", colors: "Cream, White", category: "traditional" },
      { name: "Principal Sponsor Gown", price: "₱3,200", quantity: 6, image: "../assets/images/Principal Sponsor Gown.jpg", sizes: "M, L, XL", colors: "Purple, Navy", category: "gowns" },
      { name: "Costume", price: "₱2,800", quantity: 12, image: "../assets/images/Costume.jpg", sizes: "S, M, L", colors: "Red, Green, Blue", category: "costumes" },
      { name: "Evening Dress", price: "₱8,000", quantity: 8, image: "../assets/images/dress1.jpg", sizes: "S, M, L", colors: "Black, Red, Silver", category: "dresses" },
      { name: "Casual Wear Dress", price: "₱2,500", quantity: 10, image: "../assets/images/dress2.jpg", sizes: "XS, S, M, L, XL", colors: "Floral Print, Solid Blue", category: "dresses" },
      { name: "Formal Suit", price: "₱6,000", quantity: 4, image: "../assets/images/dress3.jpg", sizes: "S, M, L, XL", colors: "Black, Charcoal", category: "suits" }
    ];
    products = mockData;
    displayProducts(mockData);
  }

  // Display products
  function displayProducts(data) {
    if (data.length === 0) {
      productList.innerHTML = '<p style="text-align: center; padding: 20px; color: #666;">No products found matching your search or filter.</p>';
      return;
    }

    productList.innerHTML = data.map(product => {
      const avgRating = getAverageRating(product.name);
      const ratingHearts = generateRatingHearts(product.name, 0);
      return `
        <div class="product" data-name="${product.name}">
          <img src="${product.image}" alt="${product.name}" onerror="this.src='../assets/images/logo.png';">
          <h3>${product.name}</h3>
          <p>${product.price}</p>
          <p>Quantity: ${product.quantity}</p>
          ${product.sizes ? `<p><strong>Sizes:</strong> ${product.sizes}</p>` : ''}
          ${product.colors ? `<p><strong>Colors:</strong> ${product.colors}</p>` : ''}
          <div class="rating-section">
            <p><strong>Rate this product:</strong> ${ratingHearts}</p>
            <p>Average Rating: ${avgRating ? avgRating.toFixed(1) + '/5' : 'No ratings yet'}</p>
          </div>
          <button class="add-to-cart">Add to Cart</button>
        </div>
      `;
    }).join('');
    attachCartListeners();
    attachRatingListeners();
  }

  // Filter products
  function filterProducts() {
    const searchText = searchBar.value.toLowerCase();
    const selectedCategory = filterSelect.value;
    const filtered = products.filter(p => 
      p.name.toLowerCase().includes(searchText) &&
      (selectedCategory === 'all' || p.category === selectedCategory)
    );
    displayProducts(filtered);
  }

  searchBar.addEventListener("input", filterProducts);
  filterSelect.addEventListener("change", filterProducts);

  function generateRatingHearts(productName, currentRating) {
  return Array.from({ length: 5 }, (_, i) => {
    const ratingValue = i + 1;
    const isFilled = ratingValue <= currentRating;

    return `
      <span class="heart ${isFilled ? 'filled' : ''}"
            data-rating="${ratingValue}"
            data-product="${productName}">
        ${isFilled ? '❤️' : '🤍'}
      </span>
    `;
    }).join('');
  }



  function attachRatingListeners() {
    document.querySelectorAll('.heart').forEach(heart => {
      heart.addEventListener('click', (e) => {
        const rating = parseInt(e.target.dataset.rating);
        const productName = e.target.dataset.product;
        saveRating(productName, rating);
        const productDiv = e.target.closest('.product');
        const avgRating = getAverageRating(productName);
        productDiv.querySelector('.rating-section p:last-child').textContent = `Average Rating: ${avgRating ? avgRating.toFixed(1) + '/5' : 'No ratings yet'}`;
        productDiv.querySelector('.rating-section p:first-child').innerHTML = `<strong>Rate this product:</strong> ${generateRatingHearts(productName, rating)}`;
        attachRatingListeners();
      });
    });
  }

  function saveRating(productName, rating) {
    let ratings = JSON.parse(localStorage.getItem('productRatings')) || {};
    if (!ratings[productName]) ratings[productName] = [];
    ratings[productName].push(rating);
    localStorage.setItem('productRatings', JSON.stringify(ratings));
  }

  function getAverageRating(productName) {
    const ratings = JSON.parse(localStorage.getItem('productRatings')) || {};
    const productRatings = ratings[productName] || [];
    return productRatings.length ? productRatings.reduce((a,b)=>a+b,0)/productRatings.length : null;
  }

  // Cart
  function attachCartListeners() {
    document.querySelectorAll(".add-to-cart").forEach(button => {
      button.addEventListener("click", () => {
        const productName = button.parentElement.dataset.name;
        const product = products.find(p => p.name === productName);
        if (!product) return;

        cart = JSON.parse(localStorage.getItem("cart")) || [];
        let existing = cart.find(item => item.name === productName);
        if (existing) existing.quantity += 1;
        else cart.push({name: productName, price: product.price, quantity: 1});

        localStorage.setItem("cart", JSON.stringify(cart));
        updateCartCount();
        button.textContent = 'Added!';
        setTimeout(()=>button.textContent='Add to Cart', 1000);
      });
    });
  }

  function updateCartCount() {
    cart = JSON.parse(localStorage.getItem("cart")) || [];
    const totalQty = cart.reduce((sum, i) => sum + i.quantity, 0);
    cartCount.textContent = `🛒 ${totalQty}`;
  }

  cartCount.addEventListener("click", () => {
    cartDropdown.classList.toggle("hidden");
    if (!cartDropdown.classList.contains("hidden")) renderCartItems();
  });

  document.addEventListener("click", (e) => {
    if (!cartContainer.contains(e.target)) cartDropdown.classList.add("hidden");
  });

  function renderCartItems() {
    cart = JSON.parse(localStorage.getItem("cart")) || [];
    if (!cart.length) {
      cartDropdown.innerHTML = '<p style="padding: 10px; text-align: center;">Cart is empty</p>';
      return;
    }

    let html = cart.map(item => `
      <div class="cart-item">
        <span>${item.name} - ${item.price} x 
          <input type="number" value="${item.quantity}" min="1" class="qty-input" data-name="${item.name}">
        </span>
        <button class="remove-btn" data-name="${item.name}">Remove</button>
      </div>
    `).join('');
    html += '<div style="padding:10px; border-top:1px solid #ccc; text-align:center;"><button id="submitCart" class="submit-btn">Submit Order</button></div>';
    cartDropdown.innerHTML = html;

    document.querySelectorAll(".remove-btn").forEach(btn => {
      btn.addEventListener("click", e => {
        e.stopPropagation();
        const name = e.target.dataset.name;
        removeFromCart(name);
        renderCartItems();
      });
    });

    document.querySelectorAll(".qty-input").forEach(input => {
      input.addEventListener("change", e => {
        e.stopPropagation();
        const name = e.target.dataset.name;
        const newQty = parseInt(e.target.value) || 1;
        if (newQty < 1) removeFromCart(name);
        else updateQuantity(name, newQty);
        renderCartItems();
      });
    });

    const submitBtn = document.getElementById("submitCart");
    if (submitBtn) {
      submitBtn.addEventListener("click", async e => {
        e.stopPropagation();
        const currentUser = JSON.parse(localStorage.getItem("currentUser"));
        if (!currentUser || !currentUser.username) {
          alert("You must be logged in to submit an order!");
          return;
        }

        if (!cart.length) { alert("Cart is empty!"); return; }

        const orderData = {
          username: currentUser.username, // ✅ fixed username
          items: cart.map(item => ({ name: item.name, price: item.price, quantity: item.quantity })),
          totalPaid: cart.reduce((sum, item) => sum + parseFloat(item.price.replace(/[^\d.]/g, '')) * item.quantity, 0),
          paymentMode: "Cash on Delivery"
        };

        try {
          const res = await fetch("/api/submit_order", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(orderData)
          });

          const result = await res.json();
          if (result.success) {
            localStorage.removeItem("cart");
            updateCartCount();
            cartDropdown.classList.add("hidden");
            alert("Order submitted successfully!");
            window.location.href = "/customer/dashboard.html";
          } else alert("Failed to submit order!");
        } catch (err) {
          console.error(err);
          alert("Error submitting order.");
        }
      });
    }
  }

  function updateQuantity(name, qty) {
    cart = JSON.parse(localStorage.getItem("cart")) || [];
    const item = cart.find(i => i.name === name);
    if (item) item.quantity = qty;
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartCount();
  }

  function removeFromCart(name) {
    cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart = cart.filter(i => i.name !== name);
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartCount();
  }
});
